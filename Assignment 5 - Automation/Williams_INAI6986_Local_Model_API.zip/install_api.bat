@echo off
cd /d "%~dp0"
echo Creating virtual environment...
python -m venv .venv
call .venv\Scripts\activate
echo Installing packages...
python -m pip install --upgrade pip
pip install -r requirements.txt
echo.
echo Installation complete.
echo Copy assignment3_selected_model_naive_bayes.joblib into this folder before starting the API.
pause
